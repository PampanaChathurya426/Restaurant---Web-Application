<!DOCTYPE html>
<html lang="en">
<head>
    
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" type="image/x-icon" href="/favicon.jpg">
    <link  rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restu Website</title>
</head>
<body>
    <header>
        <div class="header">
            <div class="headerbar">
                <div class="account">
                    <ul>
                        <a href="">
                            <li>
                                <i class="fa-solid fa-house-chimney"></i>
                            </li>
                        </a>
                        <a href="">
                            <li>
                                <i class="fa-solid fa-magnifying-glass searchicon" id="searchicon1"></i>
                            </li>
                        </a>
                        <div class="search" id="searchinput1">
                            <input type="search">
                            <i class="fa-solid fa-magnifying-glass srchicon"></i>
                    </div>
                    <a href="#">
                        <li>
                            <i class="fa-solid fa-user" id="user-mb"></i>
                        </li>
                    </a>

                        
                    </ul>
                </div>
                <div class="nav">
                    <ul>
                        <a href="" >
                          <li>Home</li>  
                        </a>
                        <a href="">
                            <li>About Us</li>  
                          </a>
                          <a href="">
                            <li>Menu</li>  
                          </a>
                          <a href="">
                            <li>Book Table</li>  
                          </a>
                    </ul>
                </div>
            </div>
            <div class="logo">
                <img src="My project.png" alt="" >

            </div>
            <div class="bar">
               <i class="fa-solid fa-bars"></i>
               <i class="fa-solid fa-xmark" id="hdcross"></i>
            </div>
            <div class="nav">
                <ul>
                    
                    <a href="#">
                        <li>Home</li>
                    </a>
                    <a href="About.html" target="_self">
                        <li>About us</li>
                    </a>
                    <a href="Menu.html" target="_self">
                        <li>Menu</li>
                    </a>
                    <a href="Book.html">
                        <li>Book Table</li>
                    </a>
                   
                    <a href="Contactus.html">
                        <li>Contact Us</li>
                    </a>
                    <a href="registration.php">
                        <li>Login</li>
                    </a>
                </ul>

            </div>
            <div class="account">
                <ul>
                    <a href="#">
                        <li>
                            <i class="fa-solid fa-house-chimney"></i>
                        </li>
                    </a>
                    <a href="#">
                        <li>
                            <i class="fa-solid fa-magnifying-glass searchicon" id="searchicon2"></i>
                        </li>
                    </a>
                    <div class="search" id="searchinput2">
                        <input type="search">
                        <i class="fa-solid fa-magnifying-glass srchicon"></i>
                    </div>
                    <a href="#">
                        
                        <li>
                            <i class="fa-solid fa-user" id="user-lap"></i>
                             
                        </li>
                    </a>
                   
                </ul>
            </div>
        </div>
    </header>
   
    <div class="home">
        <div class="main_slide">
            <div>
                <h1>Enjoy<span>Delicious Food</span> in Your Healthy Life.</h1>
                <p>South Indian cuisine is known for its unique flavors.
                     Dosa,Idli,Vada,Uttapam,Biryani,Rasam,Sambar,Poriyal,Avial, Payasam
                    
                    </p>
                <button class="white_btn" >Follow Us <i class="fa-solid fa-arrow-right-long"></i></button>
            </div>
            <div class="img1">
                <img src="food1.jpg" alt="">
            </div>
        </div>
        <div class="food-items">
            <div class="item">
                <div class="img1">
                    <img src="dosa.jpg" alt="food item" >
                </div>
            <br>
            <h3 >Dosa Sambar </h3>
            <p>  It's an Indian crepe made with a fermented batter consisting of white lentils (Urad Dal) and rice. Its served with sambar, which is a tangy lentil-based curry infused with tamarind and spices. It’s a very classic combination that is accompanied by coconut chutney. </p>
            <button class="white_btn" > See Menu</button>
            
        </div>
        <div class="item">
            <div class="img1">
                <img src="chicken 65.jpg" alt="food item" >
            </div>
        <br>
        <h3 >Chicken 65 </h3>
        <p>  Chicken 65 is a marinated fried chicken in a thick spiced batter with yoghurt finished with a tempering of curry leaves, green chillies, ginger-garlic paste. The name originated has many different stories, but it said the first time it was served in a restaurant, it was number 65 on the menu; hence, it continued being called chicken 65. </p>
        <button class="white_btn">See Menu</button>
    </div>
    <div class="item">
        <div class="img1">
            <img src="coconut rice.jpg" alt="food item" >
        </div>
    <br>
    <h3 > Coconut Rice </h3>
    <p> Coconut rice is a dish prepared by soaking white rice in coconut milk or cooking rice with coconut flakes. As both coconut and the rice-plant are commonly found in the tropics all around the world, coconut rice, too. </p>
    <button class="white_btn">See Menu</button>
</div>
    </div>
    <div div class="main_slide2">
    <div class="foodimg">
        <img src ="food2.jpg" alt="">
    </div>
    <div class="question">
        <div>
            <h2>Why People Choose Us?</h2>
        </div>
        <div>
            <div class="q-ans">
                <div>
                    <img src="food4.jpg" alt="">
                </div>
                <div>
                    <h4>Service</h4>
                    <p>Even on busy days, no customer would prefer waiting for long hours in the queue. Keeping a hungry customer waiting for too long has adverse effects on the brand image. </p>
                </div>
            </div>
            <div class="q-ans">
                <div>
                    <img src="food4.jpg" alt="">
                </div>
                <div>
                    <h4>Food</h4>
                    <p>The taste and quality of the food is what keeps the customers hooked to a restaurant. Food that is cooked to perfection has the capability to make up for anything that goes wrong in the customer’s dine-in experience.  </p>
                </div>
            </div>
            <div class="q-ans">
                <div>
                    <img src="food4.jpg" alt="">
                </div>
                <div>
                    <h4>Hygiene</h4>
                    <p>All food should be stored at the appropriate temperature to prevent spoilage and contamination, and raw meat, poultry, and seafood should be stored separately from other foods to avoid cross-contamination. Additionally, food should be handled using clean utensils and in clean containers to prevent contamination.</p>
                </div>
            </div>
           
            </div>
        </div>
    </div>
    <div class="main_slide3">
        <div class="fav-head">
           <h3>Our Popular Food Items</h3> 
           <p>South Indian cuisine is known for its unique flavors.
            Dosa,Idli,Vada,Uttapam,Biryani,Rasam,Sambar,Poriyal,Avial, Payasam
           </p>
        </div>
        <div class="fav-food">
            <div class="item">
                <div >
                    <img src="paalkatti.jpg"alt="">
                </div>
                <br>
                <h3>Palkatti Chettinadu</h3>
                <p>The paal-katti chettinad curry recipe is a paneer gravy recipe made in a Tamil Nadu-Chettinad style. It is a recipe that originated from the traditional chettinad-style curry. Bursting with flavor, this dish is a must-try. Serve along with chapathis for your next meal.</p>
                <p class="fav-price" >$2.90</p>
                
            </div>
            <div class="item">
                <div >
                    <img src="prawn.jpg"alt="">
                </div>
                <br>
                <h3>Konju Varutharaccha Curry</h3>
                <p>TA seafood lover’s paradise, this prawn recipe is filled with delicious and aromatic flavors of spices. South Indian cuisine, especially that of Kerala, is full of diverse curries and distinct regional flavors. The region is popular for its delicious fish and prawn curries cooked with fresh spices and coconut.</p>
                <p class="fav-price" >$3.90</p>
                
            </div>
            <div class="item">
                <div >
                    <img src="Hyderabadi-chicken-Biryani.jpg"alt="">
                </div>
                <br>
                <h3>Hyderabadi Dum Biryani</h3>
                <p>Hyderabadi biryani, also known as Hyderabadi dum biryani, is a style of biryani from Hyderabad, India, made with basmati rice and goat meat and cooked using the dum pukht method. Originating in the kitchens of the Nizam of Hyderabad, it combines elements of Hyderabadi and Mughlai cuisines.

                </p>
                <p class="fav-price" >$5.90</p>
                
            </div>
            <div class="item">
                <div >
                    <img src="Haleem.jpg"alt="">
                </div>
                <br>
                <h3>Haleem</h3>
                <p>Hyderabadi haleem is a type of haleem popular in the Indian city of Hyderabad. Haleem is a stew composed of meat, lentils, and pounded wheat made into a thick paste. It is originally an Arabic dish and was introduced to the Hyderabad state during the rule of the Nizams. The recipe calls for a mixture of grains like broken wheat, rice, and even oats, blended with exotic spices and herbs like rose petals and saffron.</p>
                <p class="fav-price" >$1.90</p>
                
            </div>
            <div class="item">
                <div >
                    <img src="Resarattu-Recipe.jpg"alt="">
                </div>
                <br>
                <h3>Pesarattu</h3>
                <p>Pesarattu, pesara attu, pesara dosa (mung bean dosa), or cheeldo is crepe-like bread, originating in Andhra Pradesh, India, that is similar to dosa. It is made with green gram (moong dal) batter, but, unlike dosa, it does not contain urad dal. Pesarattu is eaten as breakfast and as a snack in Andhra Pradesh.</p>
                <p class="fav-price" >$1.75</p>
                
            </div>
            <div class="item">
                <div >
                    <img src="tomato-rice.jpg"alt="">
                </div>
                <br>
                <h3>Tomato Rice</h3>
                <p> The dish can be garnished with fresh cilantro and served hot with raita (a yogurt-based side dish) and papadums (a crispy Indian flatbread).Tomato rice is a tasty and satisfying dish that can be enjoyed as a main course or as a side dish with other Indian dishes.</p>
                <p class="fav-price" >$1.50</p>
                
            </div>
        </div>
        <div class="dsgn"></div>
    </div>
    <div class="main_slide4">
        <div class="chef-feed">
            <h2>Customer <span style="color: blue;">Feedback</span></h2>
            <p>the information, insights, issues, and input shared by your community about their experiences with your company, product, or services.</p>
            <div class="chef-detail">
                <div>
                    <img src="My project.png" alt="">
                </div>
                <br>
                <div>
                    <h6>Delicious food</h6>
                    <p>"Good food is the foundation of genuine happiness." </p>
                </div>
            </div>
            <div class="chef-vic">
                <div class="cv1">
                    <i class="fa-solid fa-hand-peace"></i>
                    <h4>76</h4>
                    <p>"Peace is not the absence of conflict, it is the ability to handle." </p>
                </div>
                <div class="cv2">
                    <i class="fa-solid fa-trophy"></i>
                    <h4>987</h4>
                    <p>"Success is not just about what you accomplish."</p>
                </div>
             </div>
        </div>
        <div class="chef">
            <img src="chef2.jpg" alt="" width="500" height="700">
        </div>
    </div>
    <div class="letter">
        <div class="letter-head">
            <h2>Subscribe <span>Now!!!</span></h2>
        </div>
        <div class="letter-input">
            <div>
                <input type="email" placeholder="Example.com">

            </div>
            <button class="white_btn">Subscribe</button>
        </div>
    </div>

</div>
<div class="footer">
    <div class="footer-1">
        <div class="logo">
            <img src="My project.png" alt="">
        </div>
        <div>
            <address>
                <p>Email:chathupampana@gmail.com</p>
                <p>Declicious Food</p>
                <p>Ms. chathu 123,<br>My street,New Delhi<br>India</p>
            </address>    
        </div>
    </div>
    <div class="footer-2">
     <img src="My project.png" alt="">
     <h2>Powered by <em>Delicious Food</em></h2>
    </div>
</div>
    <script src="app1.js"></script>
</body>
</html>
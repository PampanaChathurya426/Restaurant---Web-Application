
<?php
// Establish a database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "restaurant";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$name = $_POST['name'];
$email = $_POST['email'];
$date = $_POST['date'];
$time = $_POST['time'];
$party_size = $_POST['party_size'];

// Insert data into the reservations table
$sql = "INSERT INTO reservations (name, email, date, time, party_size)
        VALUES ('$name', '$email', '$date', '$time', $party_size)";

if ($conn->query($sql) === TRUE) {
    // Close the database connection
    $conn->close();

    // Redirect to confirmation page with reservation details
    header("Location: confirmation.php?name=$name&email=$email&date=$date&time=$time&party_size=$party_size");
    exit();
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    $conn->close();
}
?>

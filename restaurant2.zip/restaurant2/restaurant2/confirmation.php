<!DOCTYPE html>
<html>
<head>
    <title>Reservation Confirmation</title>
    <style>
       /* Reset some default styles */
body, h1, p {
    margin: 0;
    padding: 0;
}

/* Global styles */
body {
    font-family: Arial, sans-serif;
    background-color: #f7f7f7;
    color: #333;
}

.container {
    max-width: 600px;
    margin: 0 auto;
    padding: 20px;
    background-color: white;
    border-radius: 5px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

h1 {
    font-size: 24px;
    margin-bottom: 10px;
}

p {
    margin: 10px 0;
    line-height: 1.4;
}

/* Styling for the confirmation message */
.confirmation-message {
    font-size: 18px;
    font-weight: bold;
    color: #007bff;
}

/* Styling for link/button */
.return-button {
    display: inline-block;
    margin-top: 10px;
    padding: 8px 20px;
    background-color: #007bff;
    color: white;
    text-decoration: none;
    border-radius: 4px;
    transition: background-color 0.3s ease;
}

.return-button:hover {
    background-color: #0056b3;
}

    </style>
</head>
<body>
    <div class="container">
        <h1>Reservation Confirmation</h1>
        <?php
        $name = $_GET['name'];
        $email = $_GET['email'];
        $date = $_GET['date'];
        $time = $_GET['time'];
        $party_size = $_GET['party_size'];

        echo "<p><strong>Name:</strong> $name</p>";
        echo "<p><strong>Email:</strong> $email</p>";
        echo "<p><strong>Date:</strong> $date</p>";
        echo "<p><strong>Time:</strong> $time</p>";
        echo "<p><strong>Party Size:</strong> $party_size</p>";
        ?>
        <p>Your reservation has been confirmed. We look forward to seeing you!</p>
    </div>
</body>
</html>

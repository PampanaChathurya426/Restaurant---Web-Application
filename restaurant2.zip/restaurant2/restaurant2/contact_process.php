<!DOCTYPE html>
<html lang="en">
<head>
    
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="Contactus.css">
    <link rel="shortcut icon" type="image/x-icon" href="/favicon.jpg">
    <link  rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restu Website</title>
</head>
<body>
    <header>
        <div class="header">
            <div class="headerbar">
                <div class="account">
                    <ul>
                        <a href="">
                            <li>
                                <i class="fa-solid fa-house-chimney"></i>
                            </li>
                        </a>
                        <a href="">
                            <li>
                                <i class="fa-solid fa-magnifying-glass searchicon" id="searchicon1"></i>
                            </li>
                        </a>
                        <div class="search" id="searchinput1">
                            <input type="search">
                            <i class="fa-solid fa-magnifying-glass srchicon"></i>
                    </div>
                    <a href="#">
                        <li>
                            <i class="fa-solid fa-user" id="user-mb"></i>
                        </li>
                    </a>

                        
                    </ul>
                </div>
                <div class="nav">
                    <ul>
                        <a href="" >
                          <li>Home</li>  
                        </a>
                        <a href="">
                            <li>About Us</li>  
                          </a>
                          <a href="">
                            <li>Menu</li>  
                          </a>
                          <a href="">
                            <li>Book Table</li>  
                          </a>
                    </ul>
                </div>
            </div>
            <div class="logo">
                <img src="My project.png" alt="" >

            </div>
            <div class="bar">
               <i class="fa-solid fa-bars"></i>
               <i class="fa-solid fa-xmark" id="hdcross"></i>
            </div>
            <div class="nav">
                <ul>
                    
                    <a href="index1.php">
                        <li>Home</li>
                    </a>
                    <a href="About.html" target="_self">
                        <li>About us</li>
                    </a>
                    <a href="Menu.html" target="_self">
                        <li>Menu</li>
                    </a>
                    <a href="Book.html">
                        <li>Book Table</li>
                    </a>
                   
                    <a href="Contactus.html">
                        <li>Contact Us</li>
                    </a>
                    <a href="registration.php">
                        <li>Login</li>
                    </a>
                </ul>

            </div>
            <div class="account">
                <ul>
                    <a href="#">
                        <li>
                            <i class="fa-solid fa-house-chimney"></i>
                        </li>
                    </a>
                    <a href="#">
                        <li>
                            <i class="fa-solid fa-magnifying-glass searchicon" id="searchicon2"></i>
                        </li>
                    </a>
                    <div class="search" id="searchinput2">
                        <input type="search">
                        <i class="fa-solid fa-magnifying-glass srchicon"></i>
                    </div>
                    <a href="#">
                        
                        <li>
                            <i class="fa-solid fa-user" id="user-lap"></i>
                             
                        </li>
                    </a>
                   
                </ul>
            </div>
        </div>
    </header>
    <body>
<?php
// Establish a database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "restaurant";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$name = $_POST['name'];
$email = $_POST['email'];
$subject = $_POST['subject'];
$message = $_POST['message'];

// Insert data into the contact_submissions table
$sql = "INSERT INTO contact_submissions2 (name, email, subject, message)
        VALUES ('$name', '$email', '$subject', '$message')";

if ($conn->query($sql) === TRUE) {
    echo "Submission successfully sent.";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the database connection
$conn->close();
?>
</body>
</html>
